#include <iostream>

#include <antlr4-runtime.h>

using namespace bx;

int main(int argc, char **argv) {
  std::cout << "Hello, world\n";
}
