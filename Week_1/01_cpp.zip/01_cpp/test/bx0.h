#include <stdio.h>
#include <stdint.h>
static const char *const __print_fmt = "%ld\n";
#define PRINT(x) printf(__print_fmt, (x))
